package com.mycompany.poobasicocomentado;//nome do pacote - categorizar classes
import java.util.Scanner; //importa a biblioteca Scanner

public class Main {
    public static void main(String[] args) { //método principal
       
        Scanner scan = new Scanner (System.in);//instanciação do objeto scan (coloque o nome que preferir) 
        Pessoa pessoa1 = new Pessoa(); 
        /*comandos de instanciação composto por:
        Pessoa   pessoa1   =             new                      Pessoa (); 
        Classe - objeto -  atribuição  - palavra reserva que      - construtor
                                         criar uma nova instância 
       */
        System.out.println("Digite o nome da pessoa");//use o atalho sout+tab para escrever System.out.println
        pessoa1.setNome(scan.nextLine());
      
        pessoa1.setNome(scan.next());
        System.out.println("Nome: " + pessoa1.getNome());
        /*
        pessoa1.setNome(scan.nextLine());
        objeto.metodo Set da classe Pessoa (parâmetro String que será o conteúdo digitado pelo usuário)
        */
        System.out.println("Digite o CPF da pessoa");
        pessoa1.setCpf(scan.next());
        
        System.out.println("O cadastro da pessoa está ativo?");
        pessoa1.setCadAdtivo(scan.nextBoolean());
        
        System.out.println("Relatorio");
        System.out.println("Nome: " + pessoa1.getNome());
        /*
        System.out.println("Nome: " + pessoa1.getNome());
                                      Chama o método getNome, do objeto pessoa1, da classe Pessoa
        */
        System.out.println("CPF: " + pessoa1.getCpf());
        System.out.println("Cadastro ativo: " + pessoa1.isCadAdtivo());
        /*
        Também pode ser feito
        System.out.println("Nome: " + pessoa1.getNome() + " CPF: " + pessoa1.getCpf() + " Cadastro ativo: " + pessoa1.isCadAdtivo());
        */      
    }
    
}

