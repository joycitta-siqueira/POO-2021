package com.mycompany.poobasicocomentado;
 /* ENCAPSULAMENTO
    O ato de empacotar ao mesmo tempo dados e objetos é denominado encapsulamento. 
    O objeto esconde seus dados de outros objetos e permite que os dados sejam acessados por intermédio de 
    seus próprios métodos.
 */
public class Pessoa {//atributos da classe pessoa;
/* VISIBILIDADE DOS ATRIBUTOS
    Privada (private): visível exclusivamente dentro da classe.
    Pública (public): completamente visível dentro e fora da classe.
    Protegida (protected): visível apenas dentro da classe, pelos seus herdeiros e pelas classes no mesmo pacote.
    Pacote (padrão): visível apenas dentro da classe e pelas classes que estão no mesmo pacote
*/
    private String nome; 
    private String cpf;
    private boolean cadAdtivo;
    private final int CONSTANTE = 2; //escreve todo o nome em letra maiuscula
    
/* MODIFICADORES - final e static 
    FINAL: Um atributo final de uma classe pode ter seu valor atribuído uma única vez, seja na própria declaração ou no construtor. 
    A idéia principal é que recursos "final" não pode ser alterados. 
    Pode ser usado em diferentes contextos, em classes, atributos e métodos:
    1. Uma classe final não pode ser transformada em subclasse.
    2. Um atributo final não pode ser modificada, ou seja, uma constante.
    3. Um método final não pode ser sobrescrito
    
    STATIC: 
    Na declaração de uma variável dentro de uma classe, para se criar uma variável que será compartilhada 
    por todas as instâncias de objetos de uma classe como um variável comum. 
    Ou seja, a variável criada será a mesma em todas instâncias e quando seu conteúdo é 
    modificado em uma das instâncias então ele será modificado em todas instâncias;
    na declaração de um método que deve ser acessado diretamente na classe e não nas suas instâncias
*/
    
    
/* MÉTODOS ESPECIAIS: CONSTRUTORES
   São métodos de uma classe que tem o mesmo nome desta classe e são chamados quando da criação de um objeto
   desta classe.
    1. São usados para “inicializar” um objeto
    2. São chamados apenas através de um comando “new”
    3. Java provê automaticamente um construtor sem parâmetros, 
    caso nenhum construtor seja declarado explicitamente
    Ex.: Pessoa pessoa1 = new Pessoa (); 
*/
    
    public Pessoa() {//Construtor
     /* Conforme mencionado, o construtor vazio é criado automaticamente pelo java. 
       Também possui as seguintes características:
        1. executado uma única vez para construir o objeto
        2. método obrigatoriamente público
        3. não possui tipo retorno
       Para ilustrar, nesse caso, criamos o construtor vazio manualmente.    
       Atalho para criar o método pela IDE: Alt`+ Insert ou botão direito -> Insert code -> Constructor
        
       Podemos criar um construtor que não seja vazio, para validação dos atributos.
       Ex.:
        
      public Pessoa(Boolean cadAtivo){
        this.cadAtivo = cadAtivo;
      }
     
      Neste caso, precisariamos alterar a linha de instancer obejeto:
        Pessoa pessoa1 = new Pessoa (cadAtivo);
    */
    }
    
    //métodos getter e setter
    //Atalho para criar os métodos pela IDE: Alt`+ Insert ou botão direito -> Insert code -> Getter ou Setter ou Getter and Setter 
    //lembre-se de marcar que deseja encapsular os campos
    public String getNome() { //Getter - método para recuperar valores
        return nome;
    }

    public void setNome(String nome) {//Setter - método para setar valores
        this.nome = nome;
    }

    public boolean isCadAdtivo() { //Quando o atributo é do tipo booleano usa-se o método is
        return cadAdtivo;
    }

    public void setCadAdtivo(boolean cadAdtivo) {
        this.cadAdtivo = cadAdtivo;
    }

    public int getCONSTANTE() {
        return CONSTANTE;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    
}
