/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.aula2903;

import java.util.Scanner;

/**
 *
 * @author Joyce
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        Cliente c = new Cliente();
        Telefone t = new Telefone();
        Endereco e = new Endereco();
        
        //cliente
        System.out.println("Digite o nome do clinete: ");
        c.setNome(scan.next());
        System.out.println("Digite o email: ");
        c.setEmail(scan.next());
        System.out.println("Digite o cpf: ");
        c.setCpf(scan.next());
        
        //preenchendo o objeto telefone
        System.out.println("Digite o tipo do telefone");
        t.setTipo(scan.next());
        System.out.println("Digite o ddd");
        t.setDdd(scan.next());
        System.out.println("Digite o numero");
        t.setNumero(scan.next());
      
        //c.setTelefone(t);
        
        //preenchendo endereço
        System.out.println("Digite a rua");
        e.setRua(scan.next());
        System.out.println("Digite a cidade");
        e.setCidade(scan.next());
        System.out.println("Digite o estado");
        e.setEstado(scan.next());
        System.out.println("Digite o cep");
        e.setCep(scan.next());
        
        c.setEnd(e);
        
        
       
     
        
        
        

        
        
    }
    
}
