/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.aula2903;

/**
 *
 * @author Joyce
 */
public class Cliente {
    
    private String nome;
    private String cpf;
    private String email;
    private Telefone telefone;
    private Endereco end;

    public Cliente() {  //construtor padrão
    }

    public Cliente(String nome, String cpf) {
        this.nome = nome;
        this.cpf = cpf;
    }
    
    public Cliente(String nome, String cpf, String email) {
        this.nome = nome;
        this.cpf = cpf;
        this.email = email;
    }

    public Cliente(String nome, String email, Telefone telefone) {
        this.nome = nome;
        this.email = email;
        this.telefone = telefone;
    }
   
    
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Telefone getTelefone() {
        return telefone;
    }

    public void setTelefone(Telefone telefone) {
        this.telefone = telefone;
    }

    public Endereco getEnd() {
        return end;
    }

    public void setEnd(Endereco end) {
        this.end = end;
    }
    
    public void imprimir(){
        System.out.println("Imprimir cliente");
        System.out.println("Nome: " + this.nome);
        System.out.println("Email: " + this.email);
        System.out.println("CPF: " + this.cpf);
        System.out.println("Telefone");
        System.out.println("Tipo: " + telefone.getTipo());
        System.out.println("DDD: " + telefone.getDdd());
        System.out.println("Numero: " + telefone.getNumero());
        System.out.println("Endereço ");
        System.out.println("Rua: " + end.getRua());
        System.out.println("Cidade: " + end.getCidade());
        
    }
    
    
    
}
