package com.mycompany.classes2203;

public class Pessoa {
    String nome;
    String cpf;
    boolean cadAtivo;
    final int CONSTANTE = 2;
    Endereco end;
    Telefone tel;

    public Pessoa() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public boolean isCadAtivo() {
        return cadAtivo;
    }

    public void setCadAtivo(boolean cadAtivo) {
        this.cadAtivo = cadAtivo;
    }

    public Endereco getEnd() {
        return end;
    }

    public void setEnd(Endereco end) {//parametro objeto
        this.end = end;
    }

    public Telefone getTel() {
        return tel;
    }

    public void setTel(Telefone tel) {
        this.tel = tel;
    }
    
    
    
    
              

}
